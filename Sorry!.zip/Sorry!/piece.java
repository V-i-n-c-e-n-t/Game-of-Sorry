
/**
 * light weight graphics object that can draw its self 
 * (its supossed theo be a circle)
 * 
 * @author (Jonathan Ho) 
 * @version (V.1 Jan 13)
 */
import javax.swing.*;
import java.awt.*;
public class piece
{
    //instance fields
    private int xLocation = 0;
    Color colour;
    private int locationValue = 0;
    // constructor
    public piece(int x)
    {
        xLocation = x;
        // sets the color
        colour = new Color(0, 255, 0);

    }
    // its draw method
    public void draw(Graphics g)
    {
        g.setColor(colour);
        g.fillOval(xLocation,0,100, 100);
    }
    // updates the x coodinate of the tile
    public void updateX(int x)
    {
        xLocation = x;
    }
    
    public void setlocationValue(int x)
    {
        locationValue = x;
    }
    
    public int getlocationValue()
    {
        return locationValue;
    }
}
