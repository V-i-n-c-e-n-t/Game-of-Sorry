
/**
 * define a windows wich has a x and y coordinate and can draw it self
 * 
 * @author (jonathan Ho) 
 * @version (1/19/16)
 */
import java.awt.*;
import javax.swing.*;

public class tile// class for makeing a tile
{
    int wide, tall, total, upperX;
    int upperY = 0;
    public  static  final int HEIGHT= 100;
    public static final int WIDTH = 100;

    // constructor that takes in a x( the tile number and translates it into the x coorinate
    public tile (int x )
    {
        upperX = x * 105;

    }
    //returns the x coodinate of the tle for use with the tile
    public int getX()
    {
        return upperX;
    }
    //draw method
    public void draw (Graphics page)//windows draw method that has a R. N. G. to randomize if the wondows will be drawn or not
    {
        page.setColor(Color.yellow);       
        page.fillRect(upperX, upperY, WIDTH, HEIGHT);
    }
}