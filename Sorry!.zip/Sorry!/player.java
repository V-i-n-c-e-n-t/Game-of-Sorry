
/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class player
{
   public player ( boolean human, int num)
   {
       
    }
}
