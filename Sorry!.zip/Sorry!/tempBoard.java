
/**
 * Write a description of class tempBoard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class tempBoard extends JPanel
{
    //instance fields
    tile[] tileArray = new tile[9];
    piece myPiece;
    int pieceLocation = 0;
    public JButton button;
    public Deck deck;
    //conctructor
    public tempBoard() {
        //setLayout(new BorderLayout());
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        c.anchor = GridBagConstraints.LAST_LINE_START;
        deck = new Deck();
       

        //creating the graphical objects
        setPreferredSize(new Dimension(1000, 400));
        //for loop for creating the amount of tiles 9 at this point
        for(int i = 0; i < 9; i++) {
            tileArray[i] = new tile(i);
        }
        myPiece = new piece(pieceLocation);

        //creating the button
        c.anchor = GridBagConstraints.LAST_LINE_END;
        button = new JButton("Advance the piece");
        button.addActionListener(new buttonListener());       
        button.setSize(new Dimension(200, 50));
        add(button, c);
    }

    public  void paintComponent(Graphics page) 
    {
        super.paintComponent(page);
        //painting the components
        for(int i = 0; i < 9; i++) {
            tileArray[i].draw(page);
        } 
        myPiece.draw(page);
    }
    
    public class buttonListener implements ActionListener {
        public void actionPerformed ( ActionEvent e) {
            // temoporary variable so the moving engline knows how many
            int temp = deck.Draw().getValue();
            
            if (temp < 0)
            {
                temp = Math.abs(temp);
                for(int times = 0; times < temp; times++) {
                if(pieceLocation != 0) 
                {
                    pieceLocation = pieceLocation - 1;
                    
                }
                else 
                {
                    pieceLocation = 7;
                }
                }
                
            }

            //advacing and looping through the small board
            for(int times = 0; times < temp; times++) {
                if(pieceLocation != 8) {
                    pieceLocation = pieceLocation + 1;
                    
                }
                else {
                    pieceLocation = 0;
                }
            }

            //updates the location of the piece
            myPiece.setlocationValue(pieceLocation);
            myPiece.updateX(tileArray[myPiece.getlocationValue()].getX());

            //repaints the panel
            repaint();
        }
    }
}